import { useEffect, useMemo, useState } from 'react'
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'

const KEY = 'juguetes-precios-v1'

const money = (n) =>
  '$' + Number(n || 0).toLocaleString('es-MX', { maximumFractionDigits: 2 })

// Costo + porcentaje (ej. 100 + 30% = 130)
const withMarkup = (cost, percent) => Math.round(cost * (100 + percent)) / 100

// Redondea hacia arriba al siguiente múltiplo (ej. 135 con paso 50 -> 150)
const roundUp = (n, step) =>
  step > 0 ? Math.ceil(n / step - 1e-9) * step : n

const load = () => {
  try {
    const d = JSON.parse(localStorage.getItem(KEY))
    if (d && Array.isArray(d.items)) return d
  } catch {}
  return { items: [], percent: 30, step: 10 }
}

export default function App() {
  const [data, setData] = useState(load)
  const [name, setName] = useState('')
  const [cost, setCost] = useState('')
  const [q, setQ] = useState('')
  const { items, percent, step } = data

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(data))
    } catch {}
  }, [data])

  const set = (patch) => setData((d) => ({ ...d, ...patch }))
  const patchItem = (id, patch) =>
    set({ items: items.map((i) => (i.id === id ? { ...i, ...patch } : i)) })

  const rows = useMemo(
    () =>
      items
        .filter((i) => i.name.toLowerCase().includes(q.trim().toLowerCase()))
        .map((i) => {
          const c = Number(i.cost) || 0
          const suggested = roundUp(withMarkup(c, percent), step)
          const final = i.final !== '' ? Number(i.final) : suggested
          return { ...i, c, suggested, final, profit: final - c }
        }),
    [items, percent, step, q]
  )

  const add = (e) => {
    e.preventDefault()
    if (!name.trim() || cost === '') return
    set({
      items: [
        { id: Date.now() + Math.random(), name: name.trim(), cost, final: '' },
        ...items,
      ],
    })
    setName('')
    setCost('')
  }

  const remove = (id) => {
    if (confirm('¿Borrar este juguete?')) set({ items: items.filter((i) => i.id !== id) })
  }

  const exportPdf = () => {
    const doc = new jsPDF()
    doc.setFontSize(16)
    doc.text('Lista de precios de juguetes', 14, 16)
    doc.setFontSize(10)
    doc.text(
      `${new Date().toLocaleDateString('es-MX')} - Ganancia: ${percent}% sobre el costo`,
      14,
      23
    )
    autoTable(doc, {
      startY: 28,
      head: [['Juguete', 'Costo', 'Precio final', 'Ganancia']],
      body: rows.map((r) => [r.name, money(r.c), money(r.final), money(r.profit)]),
      headStyles: { fillColor: [59, 91, 255] },
    })
    doc.save('precios-juguetes.pdf')
  }

  return (
    <main className="wrap">
      <h1>Precios de juguetes</h1>

      <section className="panel settings">
        <label>
          Ganancia (%)
          <input
            type="number"
            min="0"
            value={percent}
            onChange={(e) => set({ percent: Number(e.target.value) || 0 })}
          />
        </label>
        <label>
          Redondear hacia arriba a
          <select value={step} onChange={(e) => set({ step: Number(e.target.value) })}>
            <option value={0}>No redondear</option>
            <option value={5}>Múltiplos de 5</option>
            <option value={10}>Múltiplos de 10</option>
            <option value={50}>Múltiplos de 50</option>
          </select>
        </label>
      </section>

      <form className="panel add" onSubmit={add}>
        <input
          placeholder="Nombre del juguete"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="number"
          min="0"
          step="any"
          inputMode="decimal"
          placeholder="Costo"
          value={cost}
          onChange={(e) => setCost(e.target.value)}
        />
        <button className="primary">Agregar</button>
      </form>

      <div className="bar">
        <input
          type="search"
          placeholder="Buscar juguete"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button onClick={exportPdf} disabled={!rows.length}>
          Descargar PDF
        </button>
      </div>

      {items.length === 0 ? (
        <p className="empty">Aún no hay juguetes. Agrega el primero con su costo.</p>
      ) : (
        <div className="scroll">
          <table>
            <thead>
              <tr>
                <th>Juguete</th>
                <th>Costo</th>
                <th>Con {percent}%</th>
                <th>Precio final</th>
                <th>Ganancia</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>
                    <input value={r.name} onChange={(e) => patchItem(r.id, { name: e.target.value })} />
                  </td>
                  <td>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={r.cost}
                      onChange={(e) => patchItem(r.id, { cost: e.target.value })}
                    />
                  </td>
                  <td className="muted">{money(withMarkup(r.c, percent))}</td>
                  <td>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      className="final"
                      placeholder={String(r.suggested)}
                      value={r.final === r.suggested && items.find((i) => i.id === r.id).final === '' ? '' : r.final}
                      onChange={(e) => patchItem(r.id, { final: e.target.value })}
                    />
                  </td>
                  <td className="profit">{money(r.profit)}</td>
                  <td>
                    <button className="ghost" onClick={() => remove(r.id)} aria-label={`Borrar ${r.name}`}>
                      Borrar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="hint">
        El precio final se llena solo con el redondeo. Si quieres otro precio, escríbelo en esa casilla.
      </p>
    </main>
  )
}
